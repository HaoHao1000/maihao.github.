import java.util.Scanner;
public class SquarePattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size: ");
        int size = sc.nextInt();
        for ( int row = 1; row <= size; row ++ ) {
            for ( int col = 1 ; col <= size ; col ++ ) { // c o l = 1 , 2 , 3 , . . . , s i z e
                System.out.print("");

            }

            System.out.println( ) ;
        }
    }
}
